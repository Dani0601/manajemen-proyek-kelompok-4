<?php
$pageTitle = 'Detail Hero | MLBB Guide';
$pageDescription = 'Detail hero Mobile Legends: build item, emblem, battle spell, skill, statistik, dan hero counter.';
$pageCss = 'hero-detail.css';
$pageJs = 'hero-detail.js';

require BASE_PATH . '/views/layouts/header.php';
require BASE_PATH . '/views/layouts/navbar.php';
$backUrl = $baseUrl . '/hero';
$from = (string) ($_GET['from'] ?? '');
if (
    $from !== ''
    && strpos($from, $baseUrl . '/') === 0      // harus di dalam situs ini
    && strpos($from, '//') !== 0                // bukan URL protokol-relatif
    && !preg_match('/[\r\n\\\\]/', $from)       // tanpa karakter berbahaya
) {
    $backUrl = $from;
}
$backUrl = htmlspecialchars($backUrl, ENT_QUOTES, 'UTF-8');
$assetBase = htmlspecialchars(ASSET_BASE, ENT_QUOTES, 'UTF-8');
$heroId = (int) ($_GET['id'] ?? 0);

/*
 * KONTRAK UNTUK FE2 (Ali): lihat docs/hero-detail-kontrak.md
 * - Data diberikan ke HeroDetail.render(data) di hero-detail.js
 * - Id pada elemen di bawah ini TIDAK boleh diubah (dipakai JS)
 * - Alamat halaman: /hero-detail?id=<hero_id> (BUKAN /hero; /hero dicadangkan untuk daftar hero)
 * - Hero id dibaca dari ?id= dan tersedia di data-hero-id
 */
?>

<div
    class="hd"
    id="hero-detail"
    data-asset-base="<?= $assetBase ?>"
    data-hero-id="<?= $heroId ?>"
>
    <header class="hd-header">
        <a class="hd-header__back" href="<?= $backUrl ?>" aria-label="Kembali">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                 stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <path d="M20 12H4M10 6l-6 6 6 6"></path>
            </svg>
        </a>
        <h1 class="hd-header__title">Detail Hero</h1>
    </header>

    <!-- BANNER -->
    <section class="hd-section" data-hd-section="banner" aria-label="Banner hero">
        <div class="hd-banner" data-hd-panel>
            <img id="hd-banner-img" class="hd-banner__image" alt="" width="1000" height="310">
            <span id="hd-hero-name" class="visually-hidden"></span>
            <div class="hd-state-slot" hidden></div>
        </div>
    </section>

    <!-- BUILD ITEM + EMBLEM + BATTLE SPELL -->
    <section class="hd-section hd-build" data-hd-section="build" aria-labelledby="hd-build-title">
        <div class="hd-build__layout" data-hd-panel>
            <div class="hd-build__items">
                <h2 id="hd-build-title" class="hd-section__title">Build item (6 slot)</h2>
                <div class="hd-card hd-card--shadow">
                    <ol id="hd-build-items" class="hd-items" aria-labelledby="hd-build-title"></ol>
                    <div class="hd-state-slot" hidden></div>
                </div>
            </div>

            <div class="hd-build__side">
                <div id="hd-emblem" class="hd-card hd-setup hd-setup--emblem" aria-label="Emblem setup"></div>
                <div id="hd-spell" class="hd-card hd-setup hd-setup--spell" aria-label="Battle spell"></div>
            </div>

            <div class="hd-state-slot" hidden></div>
        </div>
    </section>

    <!-- SKILL HERO -->
    <section class="hd-section" data-hd-section="skills" aria-labelledby="hd-skills-title">
        <h2 id="hd-skills-title" class="hd-section__title">Skill Hero</h2>
        <div class="hd-card hd-card--line" data-hd-panel>
            <ul id="hd-skills" class="hd-skills"></ul>
            <div class="hd-state-slot" hidden></div>
        </div>
            <!-- NEW: kotak penjelasan skill yang dipilih -->
        <div id="hd-skill-detail" class="hd-skill-detail" aria-live="polite" hidden>
            <div class="hd-skill-detail__head">
                <h3 id="hd-skill-detail-name" class="hd-skill-detail__name"></h3>
                <span id="hd-skill-detail-type" class="hd-skill-detail__badge"></span>
            </div>
            <p id="hd-skill-detail-text" class="hd-skill-detail__text"></p>
        </div>
        <!-- /NEW -->
    </section>



    <!-- STATISTIK + HERO COUNTER -->
    <div class="hd-duo">

         <!-- OFFICIAL RATINGS (hanya ada di desain mobile) -->
        <section class="hd-section hd-ratings-section" data-hd-section="ratings" aria-labelledby="hd-ratings-title">
            <h2 id="hd-ratings-title" class="hd-section__title">Official Ratings</h2>
            <div class="hd-card hd-card--line" data-hd-panel>
                <dl id="hd-ratings" class="hd-ratings"></dl>
                <div class="hd-state-slot" hidden></div>
            </div>
        </section>

        <section class="hd-section" data-hd-section="stats" aria-labelledby="hd-stats-title">
            <h2 id="hd-stats-title" class="hd-section__title">Statistik Hero</h2>
            <div class="hd-card hd-card--line" data-hd-panel>
                <ul id="hd-stats" class="hd-stats"></ul>
                <div class="hd-state-slot" hidden></div>
            </div>
        </section>

       

        <section class="hd-section" data-hd-section="counters" aria-labelledby="hd-counter-title">
            <h2 id="hd-counter-title" class="hd-section__title">Hero Counter</h2>
            <div class="hd-counters" data-hd-panel>
                <div class="hd-counter hd-counter--favorable">
                    <p class="hd-pill">Hero yang menguntungkan</p>
                    <ul id="hd-counter-favorable" class="hd-counter__list"></ul>
                </div>
                <div class="hd-counter hd-counter--unfavorable">
                    <p class="hd-pill">Hero yang kurang menguntungkan</p>
                    <ul id="hd-counter-unfavorable" class="hd-counter__list"></ul>
                </div>
                <div class="hd-state-slot" hidden></div>
            </div>
        </section>
    </div>

    <!-- ATURAN ITEM SITUASIONAL -->
    <section class="hd-section" data-hd-section="situational" aria-labelledby="hd-situ-title">
        <h2 id="hd-situ-title" class="hd-section__title">Aturan Item Situasional</h2>
        <div class="hd-card hd-card--line hd-situ" data-hd-panel>
            <div class="hd-situ__block">
                <h3 id="hd-situ-rec-title" class="hd-situ__title">Rekomendasi Item &amp; Emblem</h3>
                <ul id="hd-situ-list" class="hd-rec-list" aria-labelledby="hd-situ-rec-title"></ul>
              <div id="hd-situ-none" class="hd-situ-empty" role="status" hidden>
                    <span class="hd-situ-empty__icon" aria-hidden="true">
                        <svg width="26" height="26" viewBox="0 0 24 24" fill="#fff"><rect x="4" y="10" width="4" height="10" rx="1"/><rect x="10" y="4" width="4" height="16" rx="1"/><rect x="16" y="12" width="4" height="8" rx="1"/></svg>
                    </span>
                    <p class="hd-situ-empty__title">Belum ada rekomendasi untuk kondisi ini</p>
                    <p class="hd-situ-empty__text">Aturan item situasional untuk hero ini belum tersedia</p>
                </div>
            </div>
            <div class="hd-state-slot" hidden></div>
        </div>
    </section>

    <!-- Tampil jika halaman dibuka tanpa ?id= (mis. dari menu Hero) -->
    <section id="hd-no-hero" class="hd-empty" hidden aria-labelledby="hd-no-hero-title">
        <span class="hd-empty__icon" aria-hidden="true">
            <img src="<?= $assetBase ?>/images/icons/Bar%20Chart.png" alt="" width="24" height="24">
        </span>
        <h2 id="hd-no-hero-title" class="hd-empty__title">Hero belum dipilih</h2>
        <p class="hd-empty__text">Pilih salah satu hero dari Dashboard untuk melihat detail build, skill, dan statistiknya.</p>
        <a class="hd-empty__button" href="<?= htmlspecialchars($baseUrl . '/dashboard', ENT_QUOTES, 'UTF-8') ?>">Ke Dashboard</a>
    </section>

    <p class="hd-note-dummy" id="hd-dummy-note" hidden>Data pada halaman ini masih berupa contoh untuk pratinjau tampilan.</p>
    <p id="hd-page-loading" class="visually-hidden" role="status" aria-live="polite"></p>
</div>

<script src="<?= $assetBase ?>/js/api-client.js"></script>
<script src="<?= $assetBase ?>/js/pages/hero-detail.js"></script>
<?php require BASE_PATH . '/views/layouts/footer.php'; ?>