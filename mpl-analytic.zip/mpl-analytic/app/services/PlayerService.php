<?php
// app/services/PlayerService.php

require_once __DIR__ . '/../models/Player.php';

class PlayerService
{
    private Player $playerModel;

    public function __construct(PDO $db)
    {
        $this->playerModel = new Player($db);
    }

    public function getMasterPlayers(int $page = 1, int $limit = 100)
    {
        $offset = ($page - 1) * $limit;

        return $this->playerModel->getAllPlayers($limit, $offset);
    }

    public function comparePlayers(
        int $player1Id,
        int $player2Id,
        int $seasonId = 18
    ) {
        // Ambil statistik kedua pemain sekaligus
        $rawStats = $this->playerModel->getPlayerComparisonStats(
            $player1Id,
            $player2Id,
            $seasonId
        );

        $statsP1 = null;
        $statsP2 = null;

        foreach ($rawStats as $row) {

            if ((int)$row['player_id'] === $player1Id) {
                $statsP1 = $row;
            }

            if ((int)$row['player_id'] === $player2Id) {
                $statsP2 = $row;
            }
        }

        // Pemain yang dibandingkan tidak boleh sama
        if ($player1Id === $player2Id) {
            return null;
        }

        // Jika salah satu pemain tidak memiliki data pada season yang dipilih
        if (!$statsP1 || !$statsP2) {
            return null;
        }

        $formatPlayerData = function(array $stats) {
            return [
                "player_id" => (int)$stats['player_id'],
                "player_name" => $stats['player_name'],
                "player_photo_url" => $stats['player_photo_url'] ?? null,
                "photo_url" => $stats['player_photo_url'] ?? null,
                "team_name" => $stats['team_name'],

                // 1. Radar Chart / Perbandingan Pemain
                "stats" => [
                    "kill_power" => (float)$stats['Kill Power'],
                    "farm_rate" => (float)$stats['Farm Rate'],
                    "survival" => (float)$stats['Survival'],
                    "versatility" => (float)$stats['Versatility'],
                    "objective" => (float)$stats['Objective'],
                    "teamfight" => (float)$stats['Teamfight']
                ],

                // 2. Statistik Liga
                "league_stats" => [
                    "match_played" => (int)($stats['matches_played'] ?? 0),
                    "avg_kda" => (float)($stats['avg_kda'] ?? 0),
                    "kill_participation" => (float)($stats['kill_participation'] ?? 0)
                ],

                // 3. Statistik Detail
                "detail_stats" => [
                    "gold_per_minute" => (int)round($stats['gold_per_minute'] ?? 0),
                    "damage_per_minute" => (int)round($stats['damage_per_minute'] ?? 0),
                    "objective_secured" => (int)round($stats['objective_secured'] ?? 0)
                ],

                // 4. Performa (win rate)
                "performance" => [
                    "win_rate" => (float)($stats['win_rate'] ?? 0),
                    "total_games" => (int)($stats['matches_played'] ?? 0),
                    "wins" => (int)($stats['wins'] ?? 0),
                    "losses" => (int)($stats['losses'] ?? 0)
                ],

                // Alias Bahasa Indonesia sesuai desain UI
                "statistik_liga" => [
                    "match_dimainkan" => (int)($stats['matches_played'] ?? 0),
                    "kda_rata_rata" => (float)($stats['avg_kda'] ?? 0),
                    "kill_participation" => (float)($stats['kill_participation'] ?? 0)
                ],
                "statistik_detail" => [
                    "gold_per_menit" => (int)round($stats['gold_per_minute'] ?? 0),
                    "damage_per_menit" => (int)round($stats['damage_per_minute'] ?? 0),
                    "objective_dikuasai" => (int)round($stats['objective_secured'] ?? 0)
                ],
                "performa" => [
                    "win_rate" => (float)($stats['win_rate'] ?? 0),
                    "total_game" => (int)($stats['matches_played'] ?? 0),
                    "menang" => (int)($stats['wins'] ?? 0),
                    "kalah" => (int)($stats['losses'] ?? 0)
                ]
            ];
        };

        $player1Data = $formatPlayerData($statsP1);
        $player2Data = $formatPlayerData($statsP2);

        return [
            "season" => (int)$seasonId,
            "player_1" => $player1Data,
            "player_2" => $player2Data,
            "comparison" => [
                "player_1" => $player1Data,
                "player_2" => $player2Data
            ]
        ];
    }
    public function getPlayerById(int $playerId): ?array {
        return $this->playerModel->findById($playerId);
    }

    public function getPlayerStats(int $playerId): ?array {
        $player = $this->playerModel->findById($playerId);
        if (!$player) {
            return null;
        }

        $stats           = $this->playerModel->getPlayerStats($playerId);
        $mostUsedHeroes  = $this->playerModel->getMostUsedHeroes($playerId, 5);

        // Tambahkan win_rate untuk setiap hero
        foreach ($mostUsedHeroes as &$hero) {
            $hero['win_rate'] = $hero['pick_count'] > 0
                ? round(($hero['wins'] / $hero['pick_count']) * 100, 2)
                : 0.0;
        }
        unset($hero);

        if (!empty($stats)) {
            $totalGames     = (int) ($stats['total_games'] ?? 0);
            $wins           = (int) ($stats['wins'] ?? 0);
            $losses         = (int) ($stats['losses'] ?? 0);
            $winRate        = $totalGames > 0
                ? (float) ($stats['win_rate'] ?? round(($wins / $totalGames) * 100, 2))
                : 0.0;
            $avgDurationSec = (int) ($stats['avg_duration_seconds'] ?? 0);
            $minutes        = floor($avgDurationSec / 60);
            $seconds        = str_pad((string) ($avgDurationSec % 60), 2, '0', STR_PAD_LEFT);
            $formattedDuration = "{$minutes}:{$seconds}";
            $avgKills       = (float) ($stats['avg_kills'] ?? 0);
            $avgDeaths      = (float) ($stats['avg_deaths'] ?? 0);

            // Statistik Game (sesuai spesifikasi & UI card Statistik Game)
            $stats['total_games']          = $totalGames;
            $stats['wins']                 = $wins;
            $stats['game_wins']            = $wins;
            $stats['losses']               = $losses;
            $stats['game_losses']          = $losses;
            $stats['win_rate']             = $winRate;
            $stats['avg_duration_seconds'] = $avgDurationSec;
            $stats['avg_duration']         = $formattedDuration;
            $stats['avg_kills']            = $avgKills;
            $stats['avg_kills_per_game']   = $avgKills;
            $stats['avg_deaths']           = $avgDeaths;
            $stats['avg_deaths_per_game']  = $avgDeaths;

            $gameStats = [
                'total'                => $totalGames,
                'wins'                 => $wins,
                'losses'               => $losses,
                'win_rate'             => $winRate,
                'avg_duration_seconds' => $avgDurationSec,
                'avg_duration'         => $formattedDuration,
                'avg_kills_per_game'   => $avgKills,
                'avg_deaths_per_game'  => $avgDeaths,
            ];
            $stats['game_stats'] = $gameStats;
        }

        return [
            'player'           => $player,
            'stats'            => $stats,
            'game_stats'       => $stats['game_stats'] ?? null,
            'most_used_heroes' => $mostUsedHeroes,
        ];
    }

    public function getPlayerGames(int $playerId): ?array {
        $player = $this->playerModel->findById($playerId);
        if (!$player) {
            return null;
        }

        $games = $this->playerModel->getPlayerGames($playerId);
        return [
            'player' => $player,
            'games'  => $games,
        ];
    }
}
?>